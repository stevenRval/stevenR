<?php
require "../config/conexion.php";

$sql ="SELECT id, Nombre, Dueno, 
FROM mascotas 
WHERE 1";

foreach($dbh->query($sql) as $row)
{
    $nombre=$row[1];
    $dueno =$row["dueno"];
    echo "nom:"."$nombre"."-Duen:".$dueno."<br>";
}
?>