<?php
require "../config/conexion.php";

$elimina = $_POST ["elimina"];

$sql ="DELETE FROM mascotas 
WHERE id=".$elimina." ";


if($dbh ->query($sql))
{
    echo "eliminado exitoso";
}else{
    echo "error";

}
?>

