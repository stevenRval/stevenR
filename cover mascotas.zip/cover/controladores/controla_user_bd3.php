<?php
require "../config/conexion.php";

$dueno = $_POST ["dueno"];
$nombre = $_POST ["nombre"];


$sql = "INSERT INTO `mascotas`
(Nombre, Dueno, fecha_creation) 
VALUES
(".$nombre.",".$dueno.",now())"


if($dbh->query($sql))
{
    echo "bien";
}else
{
    echo "error";
}





?>