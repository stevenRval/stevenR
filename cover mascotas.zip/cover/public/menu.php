<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
  <header class="mb-auto">
    <div>
      <h3 class="float-md-start mb-0"><a class="nav-link fw-bold py-1 px-0" href="index.php">inicio</a></h3>
      <nav class="nav nav-masthead justify-content-center float-md-end">
        <a class="nav-link fw-bold py-1 px-0 active" aria-current="page" href="eliminar.php">Eliminar mascota</a>
        <a class="nav-link fw-bold py-1 px-0" href="registro.php">Registro mascota</a>
        <a class="nav-link fw-bold py-1 px-0" href="actualizar.php">Actializar mascota</a>
        <a class="nav-link fw-bold py-1 px-0" href="mostrar.php">Mostrar mascota</a>
      </nav>
    </div>